
_interrupt:
	MOVWF      R15+0
	SWAPF      STATUS+0, 0
	CLRF       STATUS+0
	MOVWF      ___saveSTATUS+0
	MOVF       PCLATH+0, 0
	MOVWF      ___savePCLATH+0
	CLRF       PCLATH+0

;MyProject.c,3 :: 		void interrupt() {
;MyProject.c,5 :: 		if (INTCON.TMR0IF) {
	BTFSS      INTCON+0, 2
	GOTO       L_interrupt0
;MyProject.c,6 :: 		overflow_count++;    // Increment our custom counter
	INCF       _overflow_count+0, 1
;MyProject.c,9 :: 		if (overflow_count >= 31) {
	MOVLW      31
	SUBWF      _overflow_count+0, 0
	BTFSS      STATUS+0, 0
	GOTO       L_interrupt1
;MyProject.c,10 :: 		PORTB.F0 = ~PORTB.F0; // Toggle LED on RB0
	MOVLW      1
	XORWF      PORTB+0, 1
;MyProject.c,11 :: 		overflow_count = 0;   // Reset counter
	CLRF       _overflow_count+0
;MyProject.c,12 :: 		}
L_interrupt1:
;MyProject.c,14 :: 		INTCON.TMR0IF = 0;   // Clear Timer0 Interrupt Flag
	BCF        INTCON+0, 2
;MyProject.c,15 :: 		}
L_interrupt0:
;MyProject.c,16 :: 		}
L_end_interrupt:
L__interrupt5:
	MOVF       ___savePCLATH+0, 0
	MOVWF      PCLATH+0
	SWAPF      ___saveSTATUS+0, 0
	MOVWF      STATUS+0
	SWAPF      R15+0, 1
	SWAPF      R15+0, 0
	RETFIE
; end of _interrupt

_main:

;MyProject.c,18 :: 		void main() {
;MyProject.c,20 :: 		TRISB.F0 = 0;
	BCF        TRISB+0, 0
;MyProject.c,21 :: 		PORTB.F0 = 0; // Initial state OFF
	BCF        PORTB+0, 0
;MyProject.c,28 :: 		OPTION_REG = 0x07;
	MOVLW      7
	MOVWF      OPTION_REG+0
;MyProject.c,31 :: 		TMR0 = 0;
	CLRF       TMR0+0
;MyProject.c,34 :: 		INTCON.TMR0IE = 1; // Enable Timer0 Overflow Interrupt
	BSF        INTCON+0, 5
;MyProject.c,35 :: 		INTCON.GIE = 1;    // Enable Global Interrupts
	BSF        INTCON+0, 7
;MyProject.c,37 :: 		while(1) {
L_main2:
;MyProject.c,39 :: 		}
	GOTO       L_main2
;MyProject.c,40 :: 		}
L_end_main:
	GOTO       $+0
; end of _main
