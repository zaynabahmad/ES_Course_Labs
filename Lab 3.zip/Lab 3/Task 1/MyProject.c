unsigned char overflow_count = 0;

void interrupt() {
    // Check if Timer0 Interrupt Flag is set
    if (INTCON.TMR0IF) {
        overflow_count++;    // Increment our custom counter

        // After approx 31 overflows (~1 second)
        if (overflow_count >= 31) {
            PORTB.F0 = ~PORTB.F0; // Toggle LED on RB0
            overflow_count = 0;   // Reset counter
        }

        INTCON.TMR0IF = 0;   // Clear Timer0 Interrupt Flag
    }
}

void main() {
    // 1. Configure RB0 as Output
    TRISB.F0 = 0;
    PORTB.F0 = 0; // Initial state OFF

    // 2. Configure Timer0
    // OPTION_REG configuration:
    // Bit 5 (T0CS = 0): Internal instruction cycle clock
    // Bit 3 (PSA = 0): Prescaler is assigned to Timer0
    // Bits 2-0 (PS2:PS0 = 111): Prescaler rate 1:256
    OPTION_REG = 0x07;

    // 3. Initialize Timer Value
    TMR0 = 0;

    // 4. Enable Interrupts
    INTCON.TMR0IE = 1; // Enable Timer0 Overflow Interrupt
    INTCON.GIE = 1;    // Enable Global Interrupts

    while(1) {
        // Main loop is empty; Hardware handles the timing
    }
}