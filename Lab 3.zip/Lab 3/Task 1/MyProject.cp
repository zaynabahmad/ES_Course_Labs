#line 1 "F:/CIE/Year 4/Spring/Emb/Labs/Lab 3/Task 1/MyProject.c"
unsigned char overflow_count = 0;

void interrupt() {

 if (INTCON.TMR0IF) {
 overflow_count++;


 if (overflow_count >= 31) {
 PORTB.F0 = ~PORTB.F0;
 overflow_count = 0;
 }

 INTCON.TMR0IF = 0;
 }
}

void main() {

 TRISB.F0 = 0;
 PORTB.F0 = 0;






 OPTION_REG = 0x07;


 TMR0 = 0;


 INTCON.TMR0IE = 1;
 INTCON.GIE = 1;

 while(1) {

 }
}
