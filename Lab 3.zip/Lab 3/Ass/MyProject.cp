#line 1 "F:/CIE/Year 4/Spring/Emb/Labs/Lab 3/Ass/MyProject.c"





volatile unsigned int counter1 = 0;
volatile unsigned int counter2 = 0;

void interrupt() {
 if(INTCON.TMR0IF) {
 TMR0 = 6;
 INTCON.TMR0IF = 0;

 counter1++;
 counter2++;


 if(counter1 >= 2000) {
  PORTB.B0  = ! PORTB.B0 ;
 counter1 = 0;
 }


 if(counter2 >= 1000) {
  PORTB.B1  = ! PORTB.B1 ;
 counter2 = 0;
 }
 }
}

void Timer0_Init(){

 OPTION_REG = 0b00000001;
 TMR0 = 6;

 INTCON.TMR0IE = 1;
 INTCON.GIE = 1;
}

void main() {
 TRISB.F0 = 0;
 TRISB.F1 = 0;

 PORTB.B0 = 0;
 PORTB.B1 = 0;

 Timer0_Init();

 while(1) {

 }
}
