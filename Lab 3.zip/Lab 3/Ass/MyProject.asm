
_interrupt:
	MOVWF      R15+0
	SWAPF      STATUS+0, 0
	CLRF       STATUS+0
	MOVWF      ___saveSTATUS+0
	MOVF       PCLATH+0, 0
	MOVWF      ___savePCLATH+0
	CLRF       PCLATH+0

;MyProject.c,9 :: 		void interrupt() {
;MyProject.c,10 :: 		if(INTCON.TMR0IF) {
	BTFSS      INTCON+0, 2
	GOTO       L_interrupt0
;MyProject.c,11 :: 		TMR0 = 6;            // reload for 1ms (assuming 4MHz & 1:4 prescaler)
	MOVLW      6
	MOVWF      TMR0+0
;MyProject.c,12 :: 		INTCON.TMR0IF = 0;   // clear interrupt flag
	BCF        INTCON+0, 2
;MyProject.c,14 :: 		counter1++;
	MOVF       _counter1+0, 0
	ADDLW      1
	MOVWF      R0+0
	MOVLW      0
	BTFSC      STATUS+0, 0
	ADDLW      1
	ADDWF      _counter1+1, 0
	MOVWF      R0+1
	MOVF       R0+0, 0
	MOVWF      _counter1+0
	MOVF       R0+1, 0
	MOVWF      _counter1+1
;MyProject.c,15 :: 		counter2++;
	MOVF       _counter2+0, 0
	ADDLW      1
	MOVWF      R0+0
	MOVLW      0
	BTFSC      STATUS+0, 0
	ADDLW      1
	ADDWF      _counter2+1, 0
	MOVWF      R0+1
	MOVF       R0+0, 0
	MOVWF      _counter2+0
	MOVF       R0+1, 0
	MOVWF      _counter2+1
;MyProject.c,18 :: 		if(counter1 >= 2000) {
	MOVLW      7
	SUBWF      _counter1+1, 0
	BTFSS      STATUS+0, 2
	GOTO       L__interrupt7
	MOVLW      208
	SUBWF      _counter1+0, 0
L__interrupt7:
	BTFSS      STATUS+0, 0
	GOTO       L_interrupt1
;MyProject.c,19 :: 		LED1 = !LED1;    // Logical NOT for bit toggling
	MOVLW      1
	XORWF      PORTB+0, 1
;MyProject.c,20 :: 		counter1 = 0;
	CLRF       _counter1+0
	CLRF       _counter1+1
;MyProject.c,21 :: 		}
L_interrupt1:
;MyProject.c,24 :: 		if(counter2 >= 1000) {
	MOVLW      3
	SUBWF      _counter2+1, 0
	BTFSS      STATUS+0, 2
	GOTO       L__interrupt8
	MOVLW      232
	SUBWF      _counter2+0, 0
L__interrupt8:
	BTFSS      STATUS+0, 0
	GOTO       L_interrupt2
;MyProject.c,25 :: 		LED2 = !LED2;    // Logical NOT for bit toggling
	MOVLW      2
	XORWF      PORTB+0, 1
;MyProject.c,26 :: 		counter2 = 0;
	CLRF       _counter2+0
	CLRF       _counter2+1
;MyProject.c,27 :: 		}
L_interrupt2:
;MyProject.c,28 :: 		}
L_interrupt0:
;MyProject.c,29 :: 		}
L_end_interrupt:
L__interrupt6:
	MOVF       ___savePCLATH+0, 0
	MOVWF      PCLATH+0
	SWAPF      ___saveSTATUS+0, 0
	MOVWF      STATUS+0
	SWAPF      R15+0, 1
	SWAPF      R15+0, 0
	RETFIE
; end of _interrupt

_Timer0_Init:

;MyProject.c,31 :: 		void Timer0_Init(){
;MyProject.c,33 :: 		OPTION_REG = 0b00000001;   // Prescaler 1:4
	MOVLW      1
	MOVWF      OPTION_REG+0
;MyProject.c,34 :: 		TMR0 = 6;                  // Preload 6 (250 counts)
	MOVLW      6
	MOVWF      TMR0+0
;MyProject.c,36 :: 		INTCON.TMR0IE = 1;         // Enable Timer0 interrupt
	BSF        INTCON+0, 5
;MyProject.c,37 :: 		INTCON.GIE = 1;            // Global interrupt enable
	BSF        INTCON+0, 7
;MyProject.c,38 :: 		}
L_end_Timer0_Init:
	RETURN
; end of _Timer0_Init

_main:

;MyProject.c,40 :: 		void main() {
;MyProject.c,41 :: 		TRISB.F0 = 0;              // MikroC often uses .F1 or .B1
	BCF        TRISB+0, 0
;MyProject.c,42 :: 		TRISB.F1 = 0;
	BCF        TRISB+0, 1
;MyProject.c,44 :: 		PORTB.B0 = 0;
	BCF        PORTB+0, 0
;MyProject.c,45 :: 		PORTB.B1 = 0;
	BCF        PORTB+0, 1
;MyProject.c,47 :: 		Timer0_Init();
	CALL       _Timer0_Init+0
;MyProject.c,49 :: 		while(1) {
L_main3:
;MyProject.c,51 :: 		}
	GOTO       L_main3
;MyProject.c,52 :: 		}
L_end_main:
	GOTO       $+0
; end of _main
