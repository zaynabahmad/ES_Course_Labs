// LEDs connected to PORTB
#define LED1 PORTB.B0
#define LED2 PORTB.B1

// Use volatile for variables modified inside ISR
volatile unsigned int counter1 = 0;
volatile unsigned int counter2 = 0;

void interrupt() {
    if(INTCON.TMR0IF) {
        TMR0 = 6;            // reload for 1ms (assuming 4MHz & 1:4 prescaler)
        INTCON.TMR0IF = 0;   // clear interrupt flag

        counter1++;
        counter2++;

        // LED1 toggle every 2 seconds
        if(counter1 >= 2000) {
            LED1 = !LED1;    // Logical NOT for bit toggling
            counter1 = 0;
        }

        // LED2 toggle every 1 second
        if(counter2 >= 1000) {
            LED2 = !LED2;    // Logical NOT for bit toggling
            counter2 = 0;
        }
    }
}

void Timer0_Init(){
    // For 4MHz Crystal to get 1ms:
    OPTION_REG = 0b00000001;   // Prescaler 1:4
    TMR0 = 6;                  // Preload 6 (250 counts)

    INTCON.TMR0IE = 1;         // Enable Timer0 interrupt
    INTCON.GIE = 1;            // Global interrupt enable
}

void main() {
    TRISB.F0 = 0;              // MikroC often uses .F1 or .B1
    TRISB.F1 = 0;

    PORTB.B0 = 0;
    PORTB.B1 = 0;

    Timer0_Init();

    while(1) {
        // CPU is free for other logic here
    }
}