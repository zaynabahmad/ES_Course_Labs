#line 1 "F:/CIE/Year 4/Spring/Emb/Labs/Lab 2/MyProject.c"
void delay(unsigned int t)
{
 unsigned int i;
 for(i = 0; i < t; i++);
}

void main()
{
 TRISB.F0 = 0;

 while(1)
 {
 PORTB = 0x01;
 delay(50000);

 PORTB = 0x00;
 delay(50000);
 }
}
