
_delay:

;MyProject.c,1 :: 		void delay(unsigned int t)
;MyProject.c,4 :: 		for(i = 0; i < t; i++);
	CLRF       R1+0
	CLRF       R1+1
L_delay0:
	MOVF       FARG_delay_t+1, 0
	SUBWF      R1+1, 0
	BTFSS      STATUS+0, 2
	GOTO       L__delay6
	MOVF       FARG_delay_t+0, 0
	SUBWF      R1+0, 0
L__delay6:
	BTFSC      STATUS+0, 0
	GOTO       L_delay1
	INCF       R1+0, 1
	BTFSC      STATUS+0, 2
	INCF       R1+1, 1
	GOTO       L_delay0
L_delay1:
;MyProject.c,5 :: 		}
L_end_delay:
	RETURN
; end of _delay

_main:

;MyProject.c,7 :: 		void main()
;MyProject.c,9 :: 		TRISB.F0 = 0;     // Set RB0 as output
	BCF        TRISB+0, 0
;MyProject.c,11 :: 		while(1)
L_main3:
;MyProject.c,13 :: 		PORTB = 0x01;  // Turn ON RB0
	MOVLW      1
	MOVWF      PORTB+0
;MyProject.c,14 :: 		delay(50000);
	MOVLW      80
	MOVWF      FARG_delay_t+0
	MOVLW      195
	MOVWF      FARG_delay_t+1
	CALL       _delay+0
;MyProject.c,16 :: 		PORTB = 0x00;  // Turn OFF RB0
	CLRF       PORTB+0
;MyProject.c,17 :: 		delay(50000);
	MOVLW      80
	MOVWF      FARG_delay_t+0
	MOVLW      195
	MOVWF      FARG_delay_t+1
	CALL       _delay+0
;MyProject.c,18 :: 		}
	GOTO       L_main3
;MyProject.c,19 :: 		}
L_end_main:
	GOTO       $+0
; end of _main
