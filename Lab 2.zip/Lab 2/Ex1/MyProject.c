void delay(unsigned int t)
{
    unsigned int i;
    for(i = 0; i < t; i++);
}

void main()
{
    TRISB.F0 = 0;     // Set RB0 as output

    while(1)
    {
        PORTB = 0x01;  // Turn ON RB0
        delay(50000);

        PORTB = 0x00;  // Turn OFF RB0
        delay(50000);
    }
}