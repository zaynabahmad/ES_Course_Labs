#line 1 "F:/CIE/Year 4/Spring/Emb/Labs/Lab 2/external.c"
#pragma config FOSC = HS
#pragma config WDTE = OFF
#pragma config PWRTE = ON
#pragma config BOREN = OFF
#pragma config LVP = OFF
#pragma config CPD = OFF
#pragma config WRT = OFF
#pragma config CP = OFF
#line 22 "F:/CIE/Year 4/Spring/Emb/Labs/Lab 2/external.c"
void LED_Toggle(void);


void (*EXT_INT0_Callback)(void) = 0;


void interrupt ISR()
{
 if (INTF_bit)
 {
 if (EXT_INT0_Callback != 0)
 {
 EXT_INT0_Callback();
 }

 INTF_bit = 0;
 }
}


void LED_Toggle(void)
{
  RC0  = ~ RC0 ;
}

void main()
{



 TRISC0_bit = 0;
  RC0  = 0;

 TRISB0_bit = 1;




 INTEDG_bit = 0;
 INTF_bit = 0;
 INTE_bit = 1;
 GIE_bit = 1;


 EXT_INT0_Callback = LED_Toggle;

 while (1)
 {


 }
}
}
