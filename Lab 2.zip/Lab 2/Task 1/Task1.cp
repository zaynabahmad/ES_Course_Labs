#line 1 "F:/CIE/Year 4/Spring/Emb/Labs/Lab 2/Task 1/Task1.c"
void main() {

 TRISA.F0 = 1;
 TRISA.F1 = 1;


 TRISB.F0 = 0;
 TRISB.F1 = 0;


 ADCON1 = 0x06;


 PORTB.F0 = 0;
 PORTB.F1 = 0;

 while(1) {

 if (PORTA.F0 == 1) {
 PORTB.F0 = 1;
 PORTB.F1 = 1;
 Delay_ms(200);
 PORTB.F0 = 0;
 PORTB.F1 = 0;
 Delay_ms(200);
 }


 else if (PORTA.F1 == 1) {
 PORTB.F0 = 1;
 PORTB.F1 = 1;
 Delay_ms(500);
 PORTB.F0 = 0;
 PORTB.F1 = 0;
 Delay_ms(500);
 }


 else {
 PORTB.F0 = 0;
 PORTB.F1 = 0;
 }
 }
}
