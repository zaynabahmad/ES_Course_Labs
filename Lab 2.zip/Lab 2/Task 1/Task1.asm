
_main:

;Task1.c,1 :: 		void main() {
;Task1.c,3 :: 		TRISA.F0 = 1;
	BSF        TRISA+0, 0
;Task1.c,4 :: 		TRISA.F1 = 1;
	BSF        TRISA+0, 1
;Task1.c,7 :: 		TRISB.F0 = 0;
	BCF        TRISB+0, 0
;Task1.c,8 :: 		TRISB.F1 = 0;
	BCF        TRISB+0, 1
;Task1.c,11 :: 		ADCON1 = 0x06;
	MOVLW      6
	MOVWF      ADCON1+0
;Task1.c,14 :: 		PORTB.F0 = 0;
	BCF        PORTB+0, 0
;Task1.c,15 :: 		PORTB.F1 = 0;
	BCF        PORTB+0, 1
;Task1.c,17 :: 		while(1) {
L_main0:
;Task1.c,19 :: 		if (PORTA.F0 == 1) {
	BTFSS      PORTA+0, 0
	GOTO       L_main2
;Task1.c,20 :: 		PORTB.F0 = 1;      // LEDs ON
	BSF        PORTB+0, 0
;Task1.c,21 :: 		PORTB.F1 = 1;
	BSF        PORTB+0, 1
;Task1.c,22 :: 		Delay_ms(200);     // 0.2s
	MOVLW      3
	MOVWF      R11+0
	MOVLW      8
	MOVWF      R12+0
	MOVLW      119
	MOVWF      R13+0
L_main3:
	DECFSZ     R13+0, 1
	GOTO       L_main3
	DECFSZ     R12+0, 1
	GOTO       L_main3
	DECFSZ     R11+0, 1
	GOTO       L_main3
;Task1.c,23 :: 		PORTB.F0 = 0;      // LEDs OFF
	BCF        PORTB+0, 0
;Task1.c,24 :: 		PORTB.F1 = 0;
	BCF        PORTB+0, 1
;Task1.c,25 :: 		Delay_ms(200);     // 0.2s
	MOVLW      3
	MOVWF      R11+0
	MOVLW      8
	MOVWF      R12+0
	MOVLW      119
	MOVWF      R13+0
L_main4:
	DECFSZ     R13+0, 1
	GOTO       L_main4
	DECFSZ     R12+0, 1
	GOTO       L_main4
	DECFSZ     R11+0, 1
	GOTO       L_main4
;Task1.c,26 :: 		}
	GOTO       L_main5
L_main2:
;Task1.c,29 :: 		else if (PORTA.F1 == 1) {
	BTFSS      PORTA+0, 1
	GOTO       L_main6
;Task1.c,30 :: 		PORTB.F0 = 1;      // LEDs ON
	BSF        PORTB+0, 0
;Task1.c,31 :: 		PORTB.F1 = 1;
	BSF        PORTB+0, 1
;Task1.c,32 :: 		Delay_ms(500);     // 0.5s
	MOVLW      6
	MOVWF      R11+0
	MOVLW      19
	MOVWF      R12+0
	MOVLW      173
	MOVWF      R13+0
L_main7:
	DECFSZ     R13+0, 1
	GOTO       L_main7
	DECFSZ     R12+0, 1
	GOTO       L_main7
	DECFSZ     R11+0, 1
	GOTO       L_main7
	NOP
	NOP
;Task1.c,33 :: 		PORTB.F0 = 0;      // LEDs OFF
	BCF        PORTB+0, 0
;Task1.c,34 :: 		PORTB.F1 = 0;
	BCF        PORTB+0, 1
;Task1.c,35 :: 		Delay_ms(500);     // 0.5s
	MOVLW      6
	MOVWF      R11+0
	MOVLW      19
	MOVWF      R12+0
	MOVLW      173
	MOVWF      R13+0
L_main8:
	DECFSZ     R13+0, 1
	GOTO       L_main8
	DECFSZ     R12+0, 1
	GOTO       L_main8
	DECFSZ     R11+0, 1
	GOTO       L_main8
	NOP
	NOP
;Task1.c,36 :: 		}
	GOTO       L_main9
L_main6:
;Task1.c,40 :: 		PORTB.F0 = 0;
	BCF        PORTB+0, 0
;Task1.c,41 :: 		PORTB.F1 = 0;
	BCF        PORTB+0, 1
;Task1.c,42 :: 		}
L_main9:
L_main5:
;Task1.c,43 :: 		}
	GOTO       L_main0
;Task1.c,44 :: 		}
L_end_main:
	GOTO       $+0
; end of _main
