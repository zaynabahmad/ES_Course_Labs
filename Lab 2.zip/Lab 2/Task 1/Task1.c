void main() {
    // Configure Port A pins 0 and 1 as Inputs
    TRISA.F0 = 1;
    TRISA.F1 = 1;

    // Configure Port B pins 0 and 1 as Outputs
    TRISB.F0 = 0;
    TRISB.F1 = 0;

    // Configure RA0 and RA1 as Digital (Important for PIC16F877A)
    ADCON1 = 0x06;

    // Initial State: LEDs OFF
    PORTB.F0 = 0;
    PORTB.F1 = 0;

    while(1) {
        // 1. Check Switch 1 (Short Sequence)
        if (PORTA.F0 == 1) {
            PORTB.F0 = 1;      // LEDs ON
            PORTB.F1 = 1;
            Delay_ms(200);     // 0.2s
            PORTB.F0 = 0;      // LEDs OFF
            PORTB.F1 = 0;
            Delay_ms(200);     // 0.2s
        }

        // 2. Check Switch 2 (Long Sequence)
        else if (PORTA.F1 == 1) {
            PORTB.F0 = 1;      // LEDs ON
            PORTB.F1 = 1;
            Delay_ms(500);     // 0.5s
            PORTB.F0 = 0;      // LEDs OFF
            PORTB.F1 = 0;
            Delay_ms(500);     // 0.5s
        }

        // 3. No switch pressed
        else {
            PORTB.F0 = 0;
            PORTB.F1 = 0;
        }
    }
}