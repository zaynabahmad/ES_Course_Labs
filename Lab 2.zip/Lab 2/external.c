// Single file LED toggle using INT0 (mikroC PRO for PIC16F877A)

#include <xc.h>

// CONFIGURATION BITS (adjust as needed)
#pragma config FOSC = HS
#pragma config WDTE = OFF
#pragma config PWRTE = ON
#pragma config BOREN = OFF
#pragma config LVP = OFF
#pragma config CPD = OFF
#pragma config WRT = OFF
#pragma config CP = OFF

// Define LED pin
#define LED_PIN RC0

// Define button pin (INT0)
#define BUTTON_PIN RB0

// Prototype
void LED_Toggle(void);

// Global callback pointer
void (*EXT_INT0_Callback)(void) = 0;

// Interrupt service routine
void interrupt ISR()
{
    if (INTF_bit)   // Check INT0 flag
    {
        if (EXT_INT0_Callback != 0)
        {
            EXT_INT0_Callback();  // Call callback
        }

        INTF_bit = 0; // Clear interrupt flag
    }
}

// Callback function
void LED_Toggle(void)
{
    LED_PIN = ~LED_PIN;
}

void main()
{
    // ---------------------
    // Port initialization
    // ---------------------
    TRISC0_bit = 0; // LED output
    LED_PIN = 0;    // LED OFF

    TRISB0_bit = 1; // Button input

    // ---------------------
    // External Interrupt INT0
    // ---------------------
    INTEDG_bit = 0;       // Falling edge
    INTF_bit = 0;          // Clear flag
    INTE_bit = 1;          // Enable INT0
    GIE_bit = 1;           // Enable global interrupt

    // Register callback
    EXT_INT0_Callback = LED_Toggle;

    while (1)
    {
        // Main loop does nothing
        // All LED toggling handled via interrupt
    }
}
}